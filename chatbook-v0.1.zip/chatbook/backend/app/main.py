"""
FastAPI application. Defines:
  GET  /                — upload page (mobile-friendly HTML)
  POST /api/upload      — accepts file, starts job, returns job_id
  GET  /job/{job_id}    — status page (polls API)
  GET  /api/status/{id} — JSON status
  GET  /preview/{id}    — preview PDF download
  POST /api/pay/{id}    — payment stub (replace with Stripe/Razorpay)
  GET  /full/{id}       — full PDF download (only if paid)
"""

from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from jinja2 import Environment, FileSystemLoader, select_autoescape

from .pipeline.orchestrator import run_pipeline
from .services import jobs
from .settings import (
    UPLOADS_DIR, OUTPUT_DIR, STATIC_DIR, TEMPLATES_DIR,
    settings, BACKEND_ROOT,
)


app = FastAPI(title="ChatBook", version="0.1.0")

# Static files (CSS, JS for the frontend UI)
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# Jinja for the UI pages (separate from the book template)
ui_env = Environment(
    loader=FileSystemLoader(str(TEMPLATES_DIR)),
    autoescape=select_autoescape(["html"]),
)


@app.get("/", response_class=HTMLResponse)
async def index():
    template = ui_env.get_template("upload.html")
    return template.render(
        max_size_mb=settings.MAX_UPLOAD_SIZE_MB,
        currency=settings.CURRENCY_SYMBOL,
        price=settings.FULL_BOOK_PRICE,
    )


@app.get("/job/{job_id}", response_class=HTMLResponse)
async def job_page(job_id: str):
    status = jobs.load(job_id)
    if status is None:
        raise HTTPException(404, "Job not found")
    template = ui_env.get_template("status.html")
    return template.render(
        job_id=job_id,
        currency=settings.CURRENCY_SYMBOL,
        price=settings.FULL_BOOK_PRICE,
    )


@app.post("/api/upload")
async def upload(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    # Size check
    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > settings.MAX_UPLOAD_SIZE_MB:
        raise HTTPException(
            413,
            f"File too large ({size_mb:.1f}MB). Max is {settings.MAX_UPLOAD_SIZE_MB}MB."
        )

    # Save the upload
    job_id = jobs.new_job_id()
    job_upload_dir = UPLOADS_DIR / job_id
    job_upload_dir.mkdir(parents=True, exist_ok=True)
    safe_name = Path(file.filename or "chat").name
    upload_path = job_upload_dir / safe_name
    upload_path.write_bytes(contents)

    # Create job record
    jobs.create(job_id)

    # Kick off pipeline in background
    background_tasks.add_task(run_pipeline, job_id, upload_path)

    return {"job_id": job_id, "status_url": f"/job/{job_id}"}


@app.get("/api/status/{job_id}")
async def status(job_id: str):
    s = jobs.load(job_id)
    if s is None:
        raise HTTPException(404, "Job not found")
    return s.to_dict()


@app.get("/preview/{job_id}")
async def preview_pdf(job_id: str):
    s = jobs.load(job_id)
    if s is None or not s.preview_pdf:
        raise HTTPException(404, "Preview not ready")
    full_path = BACKEND_ROOT / s.preview_pdf
    if not full_path.exists():
        raise HTTPException(404, "Preview file missing")
    return FileResponse(full_path, media_type="application/pdf", filename="preview.pdf")


@app.get("/full/{job_id}")
async def full_pdf(job_id: str):
    s = jobs.load(job_id)
    if s is None or not s.full_pdf:
        raise HTTPException(404, "Full PDF not ready")
    if not s.paid:
        raise HTTPException(402, "Payment required")
    full_path = BACKEND_ROOT / s.full_pdf
    if not full_path.exists():
        raise HTTPException(404, "Full PDF file missing")
    return FileResponse(full_path, media_type="application/pdf", filename="full_book.pdf")


@app.post("/api/pay/{job_id}")
async def pay_stub(job_id: str):
    """STUB: marks job as paid. Replace with real payment webhook.

    For Stripe: create a checkout session, set the webhook URL to a new
    /api/payment-webhook endpoint that calls jobs.update(paid=True).
    Same idea for Razorpay.
    """
    s = jobs.load(job_id)
    if s is None:
        raise HTTPException(404, "Job not found")
    if s.state != "done":
        raise HTTPException(400, "Job not finished yet")
    jobs.update(job_id, paid=True)
    return {"ok": True, "download_url": f"/full/{job_id}"}
