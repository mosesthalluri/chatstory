"""
Pipeline orchestrator. The master function that takes an uploaded chat
file and produces preview + full PDFs.

Run end-to-end inside a single async task. For v0.1 we run jobs in-process
with FastAPI's BackgroundTasks. Move to a real queue (RQ, Celery) when you
have concurrent users.
"""

import traceback
from pathlib import Path

from .. import models
from ..parsers import parse_chat
from ..pipeline import stats, chunker, summarize, chapter_gen
from ..services import image_gen, pdf_render, jobs
from ..settings import OUTPUT_DIR, settings


async def run_pipeline(job_id: str, upload_path: Path) -> None:
    """End-to-end pipeline. Updates job status as it goes."""
    try:
        # 1. Parse
        jobs.update(job_id, state="parsing", progress=5, message="Reading chat file…")
        parsed = parse_chat(upload_path)

        if parsed.message_count > settings.MAX_MESSAGES:
            raise ValueError(
                f"Too many messages ({parsed.message_count}). "
                f"Maximum is {settings.MAX_MESSAGES}. Please upload a "
                f"shorter date range."
            )

        # 2. Stats
        jobs.update(job_id, state="analyzing", progress=15, message="Computing stats…")
        chat_stats = stats.compute_stats(parsed)
        jobs.update(job_id, stats=chat_stats)

        # 3. Day digests
        active_days = sum(
            1 for _, msgs in chunker.by_day(parsed.messages).items()
            if len(msgs) >= 5
        )
        jobs.update(
            job_id, state="analyzing", progress=20,
            message=f"Summarizing {active_days} active days…"
        )

        def day_progress(done, total):
            # Day summarization spans progress 20 → 60
            pct = 20 + int(40 * done / max(total, 1))
            jobs.update(job_id, progress=pct, message=f"Summarized {done}/{total} days")

        day_summaries = await summarize.summarize_all_days(
            parsed.messages, on_progress=day_progress
        )

        # 4. Week digests
        jobs.update(job_id, progress=62, message="Rolling up to weeks…")
        week_summaries = await summarize.summarize_weeks(day_summaries, parsed.messages)

        # 5. Month digests
        jobs.update(job_id, progress=70, message="Rolling up to months…")
        month_summaries = await summarize.summarize_months(week_summaries, parsed.messages)

        # 6. Book arc
        jobs.update(job_id, progress=75, message="Identifying narrative arcs…")
        arc = await summarize.identify_arc(month_summaries, chat_stats["days_span"])

        # 7. Chapter generation
        jobs.update(job_id, state="writing", progress=78, message="Writing chapters…")
        chapter_chunks = chunker.into_chapters(parsed.messages, settings.CHAPTERS_PER_BOOK)
        chapters: list[chapter_gen.Chapter] = []
        for i, (start, end, msgs) in enumerate(chapter_chunks, 1):
            ch = await chapter_gen.generate_chapter(
                index=i, start_date=start, end_date=end,
                chapter_messages=msgs,
                month_summaries=month_summaries,
                arc_context=arc,
            )
            chapters.append(ch)
            jobs.update(
                job_id,
                progress=78 + int(10 * i / len(chapter_chunks)),
                message=f"Wrote chapter {i}/{len(chapter_chunks)}",
            )

        # 8. Image generation
        jobs.update(job_id, state="rendering", progress=88, message="Generating illustrations…")
        image_dir = OUTPUT_DIR / job_id / "images"
        chapter_images = await image_gen.generate_images_for_chapters(
            [(ch.index, ch.illustration_prompt) for ch in chapters],
            image_dir,
        )
        cover_image_path = await image_gen.generate_image(
            f"{settings.IMAGE_STYLE}. cover illustration: two chat bubbles, sparkles, warm and cozy",
            image_dir / "cover",
        )

        # 9. Render PDFs
        jobs.update(job_id, state="rendering", progress=94, message="Rendering preview PDF…")

        names = chat_stats.get("senders", ["A", "B"])
        title = "Our Story"
        subtitle = " & ".join(names[:2])
        first = chat_stats["first_message_date"][:10]
        last = chat_stats["last_message_date"][:10]
        date_range = f"{first} — {last}"

        # Preview PDF
        preview_html = pdf_render.render_book_html(
            title=title, subtitle=subtitle, date_range=date_range,
            stats=chat_stats, chapters=chapters,
            chapter_images=chapter_images,
            is_preview=True,
            preview_chapter_count=settings.PREVIEW_CHAPTERS,
            cover_image=cover_image_path,
        )
        preview_path = OUTPUT_DIR / job_id / "preview.pdf"
        await pdf_render.render_html_to_pdf(preview_html, preview_path)

        # Full PDF
        jobs.update(job_id, progress=97, message="Rendering full PDF…")
        full_html = pdf_render.render_book_html(
            title=title, subtitle=subtitle, date_range=date_range,
            stats=chat_stats, chapters=chapters,
            chapter_images=chapter_images,
            is_preview=False,
            preview_chapter_count=settings.PREVIEW_CHAPTERS,
            cover_image=cover_image_path,
        )
        full_path = OUTPUT_DIR / job_id / "full.pdf"
        await pdf_render.render_html_to_pdf(full_html, full_path)

        # 10. Done
        jobs.update(
            job_id, state="done", progress=100,
            message="Your book is ready",
            preview_pdf=str(preview_path.relative_to(OUTPUT_DIR.parent)),
            full_pdf=str(full_path.relative_to(OUTPUT_DIR.parent)),
        )

    except Exception as e:
        tb = traceback.format_exc()
        jobs.update(
            job_id, state="error",
            error=f"{type(e).__name__}: {e}",
            message="Something went wrong — see error",
        )
        # Print full traceback to server logs for debugging
        print(f"Pipeline failed for job {job_id}:\n{tb}")
