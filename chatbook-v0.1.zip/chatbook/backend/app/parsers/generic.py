"""
Generic text parser. Last resort for unrecognized text formats.

Strategy: try to extract as much structure as possible from anything that
looks like "PERSON: text" lines or "PERSON [time]: text" lines. If we
can't even find that, treat the whole file as one giant message from
"narrator" so the user at least gets a book about... whatever was in there.

This parser is intentionally lenient because it's the fallback. Better
to over-include garbage than to reject a valid file. The downstream
noise filter will clean up.
"""

import re
from datetime import datetime, timedelta
from pathlib import Path

from ..models import Message, MessageKind, ParsedChat


# Patterns we'll try, in order of specificity
PATTERNS = [
    # "Alice [2024-03-15 21:43]: hey there"
    re.compile(r"^(?P<sender>[\w\s.\-_]{1,40}?)\s*\[(?P<ts>[^\]]+)\]\s*:\s*(?P<text>.+)$"),
    # "[2024-03-15 21:43] Alice: hey"
    re.compile(r"^\[(?P<ts>[^\]]+)\]\s+(?P<sender>[\w\s.\-_]{1,40}?)\s*:\s*(?P<text>.+)$"),
    # "Alice: hey there"  (no timestamp)
    re.compile(r"^(?P<sender>[\w\s.\-_]{1,40}?):\s+(?P<text>.+)$"),
]

TIMESTAMP_FORMATS = [
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
    "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M",
    "%d/%m/%Y %H:%M", "%d-%m-%Y %H:%M",
    "%m/%d/%Y %H:%M",
]


def _try_parse_ts(s: str) -> datetime | None:
    s = s.strip()
    for fmt in TIMESTAMP_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def parse(path: Path) -> ParsedChat:
    with open(path, "rb") as f:
        raw = f.read()
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1", errors="replace")

    lines = text.splitlines()
    messages: list[Message] = []
    senders: set[str] = set()
    warnings: list[str] = ["Generic text parser used — results may vary"]

    # Synthetic timestamp generator for files without real timestamps
    fake_ts = datetime(2024, 1, 1, 9, 0, 0)
    fake_step = timedelta(minutes=1)

    current_msg: Message | None = None

    for raw_line in lines:
        line = raw_line.rstrip()
        if not line:
            continue

        matched = False
        for pat in PATTERNS:
            m = pat.match(line)
            if not m:
                continue
            groups = m.groupdict()
            sender = groups["sender"].strip()
            text_content = groups["text"].strip()
            ts_str = groups.get("ts")

            # Reject obviously bad senders (too long, looks like a sentence)
            if len(sender) > 40 or sender.count(" ") > 4:
                continue

            ts = _try_parse_ts(ts_str) if ts_str else None
            if ts is None:
                ts = fake_ts
                fake_ts += fake_step

            if current_msg is not None:
                messages.append(current_msg)
            senders.add(sender)
            current_msg = Message(
                sender=sender,
                timestamp=ts,
                text=text_content,
                kind=MessageKind.TEXT,
            )
            matched = True
            break

        if not matched:
            # Continuation of previous message
            if current_msg is not None:
                current_msg.text += "\n" + line

    if current_msg is not None:
        messages.append(current_msg)

    if not messages:
        warnings.append("Couldn't extract any messages — trying fallback")
        # Last resort: dump everything as one "narrator" message
        if text.strip():
            messages.append(Message(
                sender="narrator",
                timestamp=datetime(2024, 1, 1),
                text=text[:50000],  # cap so we don't melt the LLM
                kind=MessageKind.TEXT,
            ))
            senders.add("narrator")

    return ParsedChat(
        messages=messages,
        detected_format="generic_text",
        senders=sorted(senders),
        parser_warnings=warnings,
    )
