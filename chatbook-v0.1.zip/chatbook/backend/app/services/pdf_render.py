"""
PDF rendering. We render the book as HTML (via Jinja templates), then
print to PDF using headless Chromium.

This separation matters: a designer can iterate on the HTML/CSS without
touching Python. CSS print layout beats every Python PDF library.
"""

import asyncio
import base64
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from ..settings import TEMPLATES_DIR, settings
from ..pipeline.chapter_gen import Chapter


_jinja_env = Environment(
    loader=FileSystemLoader(str(TEMPLATES_DIR)),
    autoescape=select_autoescape(["html", "xml"]),
)


def _image_to_data_uri(path: Path) -> str:
    """Inline images as data URIs so Playwright doesn't need to fetch
    them from disk during PDF render."""
    if not path.exists():
        return ""
    suffix = path.suffix.lower()
    mime = {".png": "image/png", ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg", ".svg": "image/svg+xml"}.get(suffix, "image/png")
    if suffix == ".svg":
        # Embed SVG inline, not as data URI — better rendering
        return path.read_text()
    data = base64.b64encode(path.read_bytes()).decode()
    return f'<img src="data:{mime};base64,{data}" style="width:100%;height:auto;"/>'


def render_book_html(
    *,
    title: str,
    subtitle: str,
    date_range: str,
    stats: dict,
    chapters: list[Chapter],
    chapter_images: dict[int, Path],
    is_preview: bool,
    preview_chapter_count: int,
    cover_image: Path | None = None,
) -> str:
    """Render the full HTML for the book."""
    template = _jinja_env.get_template("book.html")

    # Convert images to inline form
    chapter_image_html: dict[int, str] = {}
    for idx, path in chapter_images.items():
        chapter_image_html[idx] = _image_to_data_uri(path)

    cover_image_html = _image_to_data_uri(cover_image) if cover_image else ""

    return template.render(
        title=title,
        subtitle=subtitle,
        date_range=date_range,
        stats=stats,
        chapters=chapters,
        chapter_images=chapter_image_html,
        is_preview=is_preview,
        preview_chapter_count=preview_chapter_count,
        cover_image=cover_image_html,
        currency=settings.CURRENCY_SYMBOL,
        full_price=settings.FULL_BOOK_PRICE,
    )


async def render_html_to_pdf(html: str, output_path: Path) -> Path:
    """Render HTML string to PDF using Playwright. A5 page size."""
    # Import here so we only require playwright at runtime
    from playwright.async_api import async_playwright

    output_path.parent.mkdir(parents=True, exist_ok=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        context = await browser.new_context()
        page = await context.new_page()
        await page.set_content(html, wait_until="networkidle")
        await page.pdf(
            path=str(output_path),
            width="148mm",
            height="210mm",
            print_background=True,
            prefer_css_page_size=True,
            margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
        )
        await browser.close()

    return output_path
