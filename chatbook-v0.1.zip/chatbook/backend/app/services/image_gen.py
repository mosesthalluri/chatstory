"""
Image generation. Gemini's free tier (Nano Banana / Imagen) by default.
Falls back to a hand-drawn SVG placeholder if no API key is configured
or generation fails.

The SVG fallback exists so the app always works end-to-end, even with
zero API keys configured.
"""

import asyncio
import base64
from pathlib import Path

import httpx

from ..settings import settings


# A simple, brand-safe placeholder SVG used when no API is available or
# generation fails. It's intentionally generic so it works for any chapter.
PLACEHOLDER_SVG = """<svg viewBox="0 0 280 170" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="140" cy="95" rx="135" ry="70" fill="#F5E6D8"/>
  <path d="M 60,60 Q 60,48 72,48 L 124,48 Q 136,48 136,60 L 136,80 Q 136,92 124,92 L 102,92 L 92,102 L 94,92 L 72,92 Q 60,92 60,80 Z" fill="#F5D5C0"/>
  <path d="M 144,76 Q 144,64 156,64 L 220,64 Q 232,64 232,76 L 232,100 Q 232,112 220,112 L 184,112 L 174,122 L 176,112 L 156,112 Q 144,112 144,100 Z" fill="#C9DAC4"/>
  <g fill="#E8A87C">
    <path d="M 35,35 l 1,3 l 3,1 l -3,1 l -1,3 l -1,-3 l -3,-1 l 3,-1 z"/>
    <path d="M 245,40 l 1,3 l 3,1 l -3,1 l -1,3 l -1,-3 l -3,-1 l 3,-1 z"/>
    <path d="M 250,135 l 0.7,1.8 l 1.8,0.7 l -1.8,0.7 l -0.7,1.8 l -0.7,-1.8 l -1.8,-0.7 l 1.8,-0.7 z"/>
  </g>
</svg>"""


async def generate_image(
    prompt: str,
    output_path: Path,
    style: str | None = None,
) -> Path:
    """Generate an image and save it to output_path. Returns the path
    actually written (may be a .svg if Gemini wasn't available)."""

    style = style or settings.IMAGE_STYLE
    full_prompt = f"{style}. {prompt}"

    if not settings.GEMINI_API_KEY:
        # No API key — write the placeholder SVG
        svg_path = output_path.with_suffix(".svg")
        svg_path.write_text(PLACEHOLDER_SVG)
        return svg_path

    # Gemini 2.5 Flash Image (Nano Banana) endpoint
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-2.5-flash-image:generateContent?key={settings.GEMINI_API_KEY}"
    )
    body = {
        "contents": [{"parts": [{"text": full_prompt}]}],
        "generationConfig": {"responseModalities": ["IMAGE"]},
    }

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(url, json=body)
            resp.raise_for_status()
            data = resp.json()

        # Find the inline image data in the response
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        for part in parts:
            inline = part.get("inlineData") or part.get("inline_data")
            if inline and inline.get("data"):
                image_bytes = base64.b64decode(inline["data"])
                png_path = output_path.with_suffix(".png")
                png_path.write_bytes(image_bytes)
                return png_path

        # No image in response — fall back to SVG
        svg_path = output_path.with_suffix(".svg")
        svg_path.write_text(PLACEHOLDER_SVG)
        return svg_path

    except (httpx.HTTPError, KeyError, ValueError) as e:
        print(f"Image gen failed for prompt '{prompt[:50]}...': {e}")
        svg_path = output_path.with_suffix(".svg")
        svg_path.write_text(PLACEHOLDER_SVG)
        return svg_path


async def generate_images_for_chapters(
    chapter_prompts: list[tuple[int, str]],
    output_dir: Path,
    max_concurrent: int = 3,
) -> dict[int, Path]:
    """Generate images for many chapters in parallel."""
    output_dir.mkdir(parents=True, exist_ok=True)
    semaphore = asyncio.Semaphore(max_concurrent)
    results: dict[int, Path] = {}

    async def worker(idx: int, prompt: str):
        async with semaphore:
            target = output_dir / f"chapter_{idx}"
            results[idx] = await generate_image(prompt, target)

    await asyncio.gather(*(worker(i, p) for i, p in chapter_prompts))
    return results
