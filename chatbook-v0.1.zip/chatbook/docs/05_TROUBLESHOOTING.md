# Troubleshooting

The errors you'll actually hit, with fixes that actually work.

## Setup errors

### `python: command not found`

You don't have Python installed, or it's not on your PATH.

- **Windows:** reinstall from python.org and check "Add Python to PATH"
  on the first screen of the installer.
- **Mac:** try `python3` instead of `python`. Or install Python 3.12 via
  Homebrew: `brew install python@3.12`.
- **Linux:** `sudo apt install python3.12 python3.12-venv`.

### `pip install` fails with `error: Microsoft Visual C++ 14.0 or greater is required`

Some packages (like `pandas`, `numpy`) need a C compiler on Windows.
Install **Microsoft C++ Build Tools** from
https://visualstudio.microsoft.com/visual-cpp-build-tools/. Pick
"Desktop development with C++" workload. Restart your terminal afterwards.

### `pip install` fails with `Could not find a version that satisfies the requirement`

You're probably on Python 3.10 or older. Check with `python --version`.
ChatBook needs 3.11+.

### `playwright install chromium` fails

Network or permissions issue. Try:

```bash
# Force re-download
playwright install --force chromium

# On Linux, you may also need:
playwright install-deps chromium
```

If you're behind a corporate proxy, set `HTTPS_PROXY` first.

## Runtime errors

### `Could not detect chat format`

The parser couldn't figure out what kind of file you uploaded. Common causes:

- **It's a media-only WhatsApp export.** WhatsApp lets you export
  "without media" and "with media." Export *with* media — even though
  ChatBook only reads text, the .zip contains `_chat.txt` which we need.
- **The file is corrupted.** Try opening it in a text editor. If you
  see garbled characters, the export failed.
- **It's a screenshot, not a text export.** ChatBook doesn't OCR
  screenshots. Re-export as text from inside the chat app.

### `Too many messages (X). Maximum is 300000.`

Your chat is genuinely huge. Either:

- Bump `MAX_MESSAGES` in `.env` (and accept longer processing time and
  higher API cost).
- Pre-trim the file to a date range.
- Future feature (not in v0.1): UI date-range picker.

### `Could not reach Ollama at http://localhost:11434`

Ollama isn't running. Open a terminal and run:

```bash
ollama serve
```

Leave it running in that terminal. ChatBook needs it alive.

If `ollama serve` says "address already in use," Ollama is already
running — your error is something else (firewall, proxy). Check
`curl http://localhost:11434/api/tags` — if that works in a separate
terminal, the issue is in ChatBook's config.

### `Groq API error: 429`

You've hit the free-tier rate limit (14,400 requests per day, or 6,000
tokens per minute). Options:

- Wait 24 hours.
- Switch to Ollama (`USE_OLLAMA=true`) for the rest of today.
- Upgrade to Groq paid tier ($0.05 per million tokens).
- Reduce `CHAPTERS_PER_BOOK` to lower per-book request count.

### `Groq API error: 401`

Your `GROQ_API_KEY` is wrong or expired. Double-check it on
https://console.groq.com — copy it again carefully (no spaces, no quotes).

### `Image gen failed`

Probably a Gemini quota issue (500 images/day on free tier) or invalid
key. ChatBook silently falls back to placeholder SVGs, so books still
generate — they just look generic. Fix:

- Verify your `GEMINI_API_KEY` at https://aistudio.google.com/apikey
- If you've burned through the daily quota, wait 24 hours.
- Or simply leave `GEMINI_API_KEY` empty and accept SVG placeholders.

### Mojibake — text shows as `hÃ©llo` instead of `héllo`

Instagram-specific. The exporter writes UTF-8 bytes interpreted as
Latin-1, and we have to undo that. The Instagram parser handles this
automatically. If you see mojibake in the *output*, file an issue with
a sample message — it means our fix missed an edge case.

### PDF is blank or missing chapters

Probably a Playwright issue. Check:

- Did `playwright install chromium` finish successfully? Re-run it.
- Are there errors in the uvicorn terminal? They usually point to the
  Jinja template issue.
- Is the chapter body empty? Look at `backend/storage/jobs/{job_id}.json`
  — if `chapters` is empty, the LLM step failed.

### "Job not found" when checking status

The `backend/storage/jobs/` directory was deleted, or you're hitting
the wrong server. Re-upload.

## Performance issues

### Job sits at "Summarizing days" for ages

Normal — this is the bulk of the work. With Ollama on a GTX 1650, expect
**10-30 seconds per active day**. A 200k-message chat with 600 active
days takes 100-300 minutes.

Speed it up:

- Switch to Groq (`USE_OLLAMA=false`) — same step takes 5-10 minutes.
- Increase `max_concurrent` in `summarize.py` (default 4) if you have
  enough RAM. Watch memory: each concurrent Ollama request needs ~2GB.

### Laptop fan is screaming

That's Ollama maxing out your CPU/GPU. Options:

- Switch to Groq for any non-test job.
- Cap Ollama's CPU usage: `OLLAMA_NUM_THREAD=2 ollama serve`
- Run jobs overnight when you're not using the laptop.

### Out of memory

8GB RAM is tight when running Ollama (5GB for Llama 3.1 8B) plus
ChatBook plus a browser. Close other apps, or:

- Use a smaller Ollama model: `ollama pull llama3.2:3b` and set both
  Ollama model envs to `llama3.2:3b`.
- Switch to Groq, which uses no local RAM beyond the HTTP request.

## When things go really wrong

1. Check the uvicorn terminal — it logs full Python tracebacks.
2. Check `backend/storage/jobs/{job_id}.json` — the `error` field has
   the failure reason.
3. Set `DEBUG=true` in `.env` and restart for more verbose logs.
4. If it's a parser issue, try the file with the generic parser by
   renaming to `something.txt` (loses some structure but often works).
